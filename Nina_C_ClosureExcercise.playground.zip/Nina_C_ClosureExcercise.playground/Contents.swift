import UIKit

var twoNumbers = {
    (num1: Int, num2: Int) -> Int in
    return num1 * num2
}

print(twoNumbers(5,95))
